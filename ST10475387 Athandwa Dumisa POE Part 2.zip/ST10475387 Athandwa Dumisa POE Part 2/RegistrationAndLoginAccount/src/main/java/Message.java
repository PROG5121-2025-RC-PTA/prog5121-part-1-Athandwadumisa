/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author User
 */
public class Message {
    
public static void main(String[] args) {

    private String messageID;
    private String messageHash;
    private String recipient;
    private String content;
    private String firstWord;
    private String lastWord;
    
    public Message(String messageID, String recipient, String content) throws NoSuchAlgorithmException{
        this.messageID = messageID;
        this.recipient = recipient;
        this.content = content;
        this.messageHash = createMessage();
        String[] words = content.trim().split("\\s+");
        this.firstWord = words.length > 0 ? words[0] : "";
        this.lastWord = words.length > 0 ? words[words.length - 1] : "";
    }
    
    public boolean checkMessage(){
        return messageID != null && messageID.length() <= 10;
    }
    
    public boolean checkRecipientCell() {
        if (recipient == null || recipient.length() > 10 || !recipient.startsWith("+"))
            return false;
        String numberPart = recipient.substring(1);
        return numberPart.matches("\\d+");
    }
    
    public String createMessage() throws NoSuchAlgorithmException{
        String combined = messageID + recipient + content;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(combined.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02X", b));
    }
    StringBuilder displayHash = new StringBuilder();
            for (int i = 0; i < sb.length(); i += 2) {
                if (i > 0) displayHash.append(":");
                displayHash.append(sb.substring(i, i + 2));
            }
            return displayHash.toString();
        } catch (NoSuchAlgorithmException e) {
            return "ErrorHashing";
        }
    }
    
    public void printMessage() {
        System.out.println("Message ID: " + messageID);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Content: " + content);
        System.out.println("First Word: " + firstWord);
        System.out.println("Last Word: " + lastWord);
    }

    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }

}

    
    
    
    
    
    
    
    

