/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class MessageManager {
    private List<Message> storedMessages = new ArrayList<>();

    public void storeMessage(Message msg) {
        storedMessages.add(msg);
        saveMessagesToFile();
    }

    public int getTotalMessages() {
        return storedMessages.size();
    }

    public List<Message> getRecentMessages(int count) {
        int size = storedMessages.size();
        int start = Math.max(size - count, 0);
        return storedMessages.subList(start, size);
    }

    private void saveMessagesToFile() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter("ChatGPT.json")) {
            gson.toJson(storedMessages, writer);
            System.out.println("Stored messages saved to ChatGPT.json");
        } catch (IOException e) {
            System.out.println("Error saving messages: " + e.getMessage());
        }
    }

    void storeMessage(Message message) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    
    
    
    
    
      

