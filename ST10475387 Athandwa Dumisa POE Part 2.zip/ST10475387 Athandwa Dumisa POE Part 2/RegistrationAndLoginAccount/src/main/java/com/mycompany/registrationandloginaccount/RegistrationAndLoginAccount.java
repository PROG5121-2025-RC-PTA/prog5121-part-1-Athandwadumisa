/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandloginaccount;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author User
 */
public class RegistrationAndLoginAccount {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //Username authentication
        String username = "";
        while (true) { 
            System.out.println("Enter a username(containing an underscore and is no more than 5 characters long):");
            username = scanner.nextLine();
            if (isValidUsername(username)) {
                break;  
            } else {
                System.out.println("Username is not correctly formatted please ensure that your username contains an underscore and is no more than five characters in length.");
            }    
        }
        //Password authentication
        String password = "";
        while (true) {
            System.out.println("Enter a password(containing at least eight characters, a capital letter, a number, and a special character):");
            password = scanner.nextLine();
            if (isValidPassword(password)) {
                break;        
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");               
            }          
        }
        
        //Cell phone number authentication
        String phoneNumber = "";
        while (true) {
            System.out.println("Enter your South African phone number:");
            phoneNumber = scanner.nextLine();
            if (isValidPhoneNumber(phoneNumber)) {
                break;               
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }
        
        //Output valid data
        System.out.println("\nAccount Created Successfully!");
        System.out.println("Username successfully captured:" + username);
        System.out.println("Password successfully captured:" + password);
        System.out.println("Cell Phone Number successfully added:" + phoneNumber);
        
    }
    
    //Authenticate username
    private static boolean isValidUsername(String username) {
        return username.length() <= 5 && username.contains("_");
        
    }

    //Authenticate password
    private static boolean isValidPassword(String password) {
        if(password.length() <8) return false;
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        
        for (int i = 0; i<password.length(); i++){
            char ch = password.charAt(i);
            if (Character.isUpperCase(ch)) hasUpper = true;
            if (Character.isDigit(ch)) hasDigit = true;
            if (!Character.isLetterOrDigit(ch)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
        
    }

    //Authenticate South African cell phone number
    private static boolean isValidPhoneNumber(String phoneNumber) {
        String regex = "^\\+27\\d{8}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    
    }
}
