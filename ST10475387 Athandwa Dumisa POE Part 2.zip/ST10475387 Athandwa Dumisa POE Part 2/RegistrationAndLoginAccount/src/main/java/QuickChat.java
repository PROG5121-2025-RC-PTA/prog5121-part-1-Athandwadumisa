/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.security.NoSuchAlgorithmException;
import java.util.*;
/**
 *
 * @author User
 */
public class QuickChat {
    public static void main(String[] args) throws NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        MessageManager manager = new MessageManager();

        System.out.print("Enter the number of messages you wish to send: ");
        int maxMessages = scanner.nextInt();
        scanner.nextLine();

        boolean exit = false;
        while (!exit) {
            System.out.println("\n=== Menu ===");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    for (int i = 0; i < maxMessages; i++) {
                        System.out.print("Enter recipient (with country code): ");
                        String recipient = scanner.nextLine();
                        if (!recipient.startsWith("+") || recipient.length() > 10 || !recipient.substring(1).matches("\\d+")) {
                            System.out.println("Invalid recipient number. Try again.");
                            i--;
                            continue;
                        }
                        System.out.print("Enter message content: ");
                        String content = scanner.nextLine();
                        String messageID = UUID.randomUUID().toString().substring(0, 10);

                        Message message = new Message(messageID, recipient, content);
                        System.out.println("Generated Message Hash: " + message.createMessage());

                        System.out.println("Choose option:");
                        System.out.println("1. Send Message");
                        System.out.println("2. Discard");
                        System.out.println("3. Store for later");
                        int option = scanner.nextInt();
                        scanner.nextLine();

                        switch (option) {
                            case 1:
                                System.out.println("Message sent successfully.");
                                break;
                            case 2:
                                System.out.println("Message discarded.");
                                break;
                            case 3:
                                manager.storeMessage(message);
                                System.out.println("Message stored successfully.");
                                break;
                            default:
                                System.out.println("Invalid option.");
                        }
                    }
                    break;
                case 2:
                    List<Message> recent = manager.getRecentMessages(maxMessages);
                    System.out.println("\n--- Recently Sent Messages ---");
                    for (Message m : recent) {
                        m.printMessage();
                        System.out.println("-----");
                    }
                    break;
                case 3:
                    System.out.println("Exiting. Goodbye!");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }

        scanner.close();
    }
}
