/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandloginmessageapp1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Pattern;

/**
 *
 * @author User
 */
public class RegistrationAndLoginMessageApp1 {

    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    
    public static void main(String[] args) {
        loginUser();
        showMenu();
    }

    public static void loginUser() {
        String username = JOptionPane.showInputDialog("Enter username (must contain '_'):");
        String password = JOptionPane.showInputDialog("Enter password (8+ characters, uppercase, number, special characters):");

        if (validateUsername(username) && validatePassword(password)) {
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
        } else {
            JOptionPane.showMessageDialog(null, "Invalid login details. Please try again.");
            loginUser();
        }
    }

    public static boolean validateUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean validatePassword(String password) {
        return password.length() >= 8 &&
               Pattern.compile("[A-Z]").matcher(password).find() &&
               Pattern.compile("[0-9]").matcher(password).find() &&
               Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();
    }

    public static void showMenu() {
        String[] options = {"Send Message", "Show Sent Messages", "Quit"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "QuickChat Menu",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0 -> sendMessage();
            case 1 -> showSentMessages();
            case 2 -> JOptionPane.showMessageDialog(null, "Goodbye!");
        }
    }

    public static void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient's phone number (+XX followed by digits):");
        if (!validatePhoneNumber(recipient)) {
            JOptionPane.showMessageDialog(null, "Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.");
            return;
        }

        String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (message.length() > 250) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters");
            return;
        }

        int messageChoice = JOptionPane.showOptionDialog(null, "How would you like to proceed?",
                "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                new String[]{"Send", "Store", "Discard"}, "Send");

        String messageID = generateMessageID();
        String messageHash = createMessageHash(messageID, message);

        if (messageChoice == 0) {
            sentMessages.add(message);
            JOptionPane.showMessageDialog(null, "Message successfully sent!\nID: " + messageID + "\nHash: " + messageHash);
        } else if (messageChoice == 1) {
            storedMessages.add(message);
            JOptionPane.showMessageDialog(null, "Message successfully stored.");
        } else {
            disregardedMessages.add(message);
            JOptionPane.showMessageDialog(null, "Message discarded.");
        }

        showMenu();
    }

    public static boolean validatePhoneNumber(String phone) {
        return phone.matches("^\\+\\d{1,3}\\d{10}$");
    }

    public static String generateMessageID() {
        return String.valueOf(new Random().nextInt(900000000) + 100000000);
    }

    public static String createMessageHash(String messageID, String message) {
        String[] words = message.split(" ");
        return messageID.substring(0, 2) + ":" + words[0] + words[words.length - 1];
    }

    public static void showSentMessages() {
        StringBuilder output = new StringBuilder("Sent Messages:\n");
        for (String msg : sentMessages) {
            output.append(msg).append("\n");
        }
        JOptionPane.showMessageDialog(null, output.toString());
        showMenu();
    }
}
